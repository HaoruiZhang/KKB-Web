export default class S3{
    constructor(){
        this.name = "技能三";
        this.ico = "./sources/skills/16630.png"
    }
    release(){
        // console.log(this);
        console.log("释放了技能" + this.name);
    }
}