export default class S1{
    constructor(){
        this.name = "技能一";
        this.ico = "./sources/skills/16610.png"
    }
    release(){
        console.log("释放了技能" + this.name);
    }
}