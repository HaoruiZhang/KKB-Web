export default class S3s{
    constructor(){
        this.name = "技能二";
        this.ico = "./sources/skills/16630.png"
    }
    release(){
        console.log("释放了技能" + this.name);
    }
}