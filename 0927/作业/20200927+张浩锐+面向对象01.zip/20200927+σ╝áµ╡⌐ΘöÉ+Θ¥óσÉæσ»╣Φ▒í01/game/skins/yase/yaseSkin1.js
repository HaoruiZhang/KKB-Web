export default class Skin1 {
    constructor() {
        this.name = "亚瑟";
        this.ico = "./sources/skins/301660.png"

    }
}