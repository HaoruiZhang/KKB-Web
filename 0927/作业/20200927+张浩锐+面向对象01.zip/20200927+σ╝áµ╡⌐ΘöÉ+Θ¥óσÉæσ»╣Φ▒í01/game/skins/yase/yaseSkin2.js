export default class Skin2 {
    constructor() {
        this.name = "龙骑士";
        this.ico = "./sources/skins/301661.png"
    }
}