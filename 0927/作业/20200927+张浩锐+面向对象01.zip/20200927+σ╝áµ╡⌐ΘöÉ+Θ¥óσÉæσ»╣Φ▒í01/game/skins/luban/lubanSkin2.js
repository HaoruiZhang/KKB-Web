export default class lubanSkin2 {
    constructor() {
        this.name = "绿皮";
        this.ico = "./sources/skins/301121.png"
    }
}