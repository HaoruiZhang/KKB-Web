export default class lubanSkin3 {
    constructor() {
        this.name = "红皮";
        this.ico = "./sources/skins/301122.png"
    }
}