export default class lubanSkin1 {
    constructor() {
        this.name = "鲁班七号";
        this.ico = "./sources/skins/301120.png"
    }
}