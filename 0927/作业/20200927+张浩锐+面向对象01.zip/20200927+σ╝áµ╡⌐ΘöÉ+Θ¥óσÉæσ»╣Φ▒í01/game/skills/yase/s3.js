export default class S3{
    constructor(){
        this.name = "技能一";
        this.ico = "./sources/skills/16630.png"
    }
}